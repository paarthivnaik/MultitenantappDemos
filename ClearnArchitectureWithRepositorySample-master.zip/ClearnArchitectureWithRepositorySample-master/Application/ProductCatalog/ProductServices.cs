﻿namespace Application.ProductCatalog
{
    internal class ProductServices : IProductServices
    {
    }
}
