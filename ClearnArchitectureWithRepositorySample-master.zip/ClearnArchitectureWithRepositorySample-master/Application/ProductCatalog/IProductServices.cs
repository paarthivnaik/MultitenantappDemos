﻿namespace Application.ProductCatalog
{
    internal interface IProductServices
    {
    }
}
