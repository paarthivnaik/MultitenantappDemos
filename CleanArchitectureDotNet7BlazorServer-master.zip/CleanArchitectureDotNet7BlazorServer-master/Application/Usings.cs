﻿global using AutoMapper;
global using Domain.Master;