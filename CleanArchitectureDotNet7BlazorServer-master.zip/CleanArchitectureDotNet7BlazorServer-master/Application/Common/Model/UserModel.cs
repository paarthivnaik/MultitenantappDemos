﻿namespace Application.Common.Model
{
    public class UserModel
    {
        public string UserId { get; set; } = string.Empty;

        public string UserName { get; set; } = string.Empty; 
        
        public string UserEmail { get; set; } = string.Empty;
    }
}
