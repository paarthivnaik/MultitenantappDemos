﻿namespace Application.Common.Interface
{
    public interface ICurrentUserService
    {
    }
}
