﻿namespace Application.Common.Error
{
    internal class ExceptionHandling : Exception
    {

    }
}
