﻿using Application.Common.Interface;

namespace WebApp.Data
{
    public class CurrentUserService : ICurrentUserService
    {
    }
}
