﻿using Microsoft.Extensions.Configuration;

namespace Infrastructure
{
    public class ConfigurationExtensions 
    {
    }
}
